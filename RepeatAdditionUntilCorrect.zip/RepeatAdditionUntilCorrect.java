import java.util.Scanner;
public class RepeatAdditionUntilCorrect {
	public static void main(String[] args) {
	byte num1=(byte)(Math.random()*10+1);
	byte num2=(byte)(Math.random()*10+1);
	Scanner input = new Scanner(System.in);
	System.out.println("enter result of "+num1+"+"+num2);
	byte res=input.nextByte();
	if (res==num1+num2){
	System.out.println("correct");
	}else{
	System.out.println("not correct , try again");
	System.out.println(num1+"+"+num2);
	while (res != num1+num2 ){
	byte res2=input.nextByte();
	if(res2 !=num1+num2){
	System.out.println("not correct , try again");
	System.out.println(num1+"+"+num2);
	continue;
	}else {
	System.out.println("correct");
	break;
	}
    }}
}}